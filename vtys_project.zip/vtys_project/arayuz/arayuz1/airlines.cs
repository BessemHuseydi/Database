﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace arayuz1
{
    public partial class airlines : Form
    {
        public airlines()
        {
            InitializeComponent();
        }
        NpgsqlConnection baglanti = new NpgsqlConnection("Server=localHost;Port=5433;Database=VERI_TABANI_PROJE;User ID=postgres;Password=1234;");
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string sorgu = "select * from airlines order by airline_id";
                NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu, baglanti);
                DataSet ds = new DataSet();
                da.Fill(ds);
                dataGridView1.DataSource = ds.Tables[0];
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
        }
       

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            p1.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            p2.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            p3.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();

        }

        private void button7_Click(object sender, EventArgs e)
        {
            baglanti.Open();

            try
            {
                NpgsqlCommand komut1 = new NpgsqlCommand("INSERT INTO airlines (airline_id, name, country) VALUES (@p1, @p2, @p3)", baglanti);

                komut1.Parameters.AddWithValue("@p1", int.Parse(p1.Text));
                komut1.Parameters.AddWithValue("@p2", p2.Text);
                komut1.Parameters.AddWithValue("@p3", p3.Text);
                komut1.ExecuteNonQuery();

                MessageBox.Show("Airline information has been successfully added");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                baglanti.Close();
            }

        }

        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void p4_TextChanged(object sender, EventArgs e)
        {
            try
            {
                // p4.Text'i kullanarak kullanıcının girdiği metni alın
                string aramaMetni = p4.Text;

                // Veritabanından veri çekme sorgusu (LOWER ile küçük harfe çevriliyor)
                string sorgu = "SELECT * FROM airlines WHERE LOWER(name) LIKE LOWER('%" + aramaMetni + "%')";

                // NpgsqlDataAdapter ve DataSet oluşturma
                NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu, baglanti);
                DataSet ds = new DataSet();

                // Verileri DataSet'e doldurma
                da.Fill(ds);

                // DataGridView'e DataSet'ten gelen verileri aktarma
                dataGridView1.DataSource = ds.Tables[0];
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }

        }

        private void button8_Click(object sender, EventArgs e)
        {
            try
            {
                // DataGridView'den seçili satırı alma
                if (dataGridView1.SelectedRows.Count > 0)
                {
                    // Seçilen satırın airline_id değerini al
                    int airlineID = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["airline_id"].Value);

                    // Veritabanından veri silme sorgusu
                    string sorgu = "DELETE FROM airlines WHERE airline_id = @AirlineID";

                    // NpgsqlCommand oluşturma
                    using (NpgsqlCommand cmd = new NpgsqlCommand(sorgu, baglanti))
                    {
                        // Parametre ekleme
                        cmd.Parameters.AddWithValue("@AirlineID", airlineID);

                        // Bağlantıyı açma
                        baglanti.Open();

                        // Sorguyu çalıştırma
                        cmd.ExecuteNonQuery();
                    }

                    // Silinen veriyi DataGridView'den kaldırma
                    dataGridView1.Rows.RemoveAt(dataGridView1.SelectedRows[0].Index);

                    MessageBox.Show("The data has been deleted successfully.");
                }
                else
                {
                    MessageBox.Show("Please select a row to delete.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("error: " + ex.Message);
            }
            finally
            {
                // Bağlantıyı kapatma
                baglanti.Close();
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            try
            {
                // Kullanıcıdan güncellenecek airline_id'yi al
                if (int.TryParse(p1.Text, out int airlineID))
                {
                    // Veritabanından veri güncelleme sorgusu
                    string sorgu = "UPDATE airlines SET name = @Name, country = @Country WHERE airline_id = @AirlineID";

                    using (NpgsqlCommand cmd = new NpgsqlCommand(sorgu, baglanti))
                    {
                        // Yeni değerleri al
                        string name = p2.Text;
                        string country = p3.Text;

                        // Parametreleri ekleyin
                        cmd.Parameters.AddWithValue("@AirlineID", airlineID);
                        cmd.Parameters.AddWithValue("@Name", name);
                        cmd.Parameters.AddWithValue("@Country", country);

                        // Bağlantıyı açın
                        baglanti.Open();

                        // Sorguyu çalıştırın
                        int affectedRows = cmd.ExecuteNonQuery();

                        if (affectedRows > 0)
                        {
                            MessageBox.Show("The data has been updata successfully.");
                        }
                        else
                        {
                            MessageBox.Show("Belirtilen airline_id bulunamadı.");
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Please select a row to updata.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
            finally
            {
                // Bağlantıyı kapatın
                baglanti.Close();
            }


        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            flights flight1 = new flights();
            flight1.ShowDialog();
        }
    }
}
