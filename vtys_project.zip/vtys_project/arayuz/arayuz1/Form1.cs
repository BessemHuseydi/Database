﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace arayuz1
    
        
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        NpgsqlConnection baglanti = new NpgsqlConnection("Server=localHost;Port=5433;Database=VERI_TABANI_PROJE;User ID=postgres;Password=1234;");


        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        
        void baslangis()
        {
            string sorgu = "select * from views1";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu, baglanti);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
        }
        
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string sorgu = "select * from views1";
                NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu, baglanti);
                DataSet ds = new DataSet();
                da.Fill(ds);
                dataGridView1.DataSource = ds.Tables[0];
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
          
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                int selectedRowIndex = dataGridView1.SelectedRows[0].Index;
                int selectedId = Convert.ToInt32(dataGridView1.Rows[selectedRowIndex].Cells["ID"].Value);
                // Burada "Id" sütununun adını değiştirmeniz gerekebilir

                try
                {
                    using (NpgsqlConnection connection = new NpgsqlConnection("Server=localhost;Port=5432;Database=VERI_TABANI_PROJE;User ID=postgres;Password=1234;"))
                    {
                        connection.Open();
                        string silmeSorgusu = "DELETE FROM views1 WHERE Id = @Id"; // "views1" tablosunun adını ve "Id" sütununun adını değiştirmeniz gerekebilir
                        using (NpgsqlCommand cmd = new NpgsqlCommand(silmeSorgusu, connection))
                        {
                            cmd.Parameters.AddWithValue("@Id", selectedId);
                            cmd.ExecuteNonQuery();
                        }
                    }

                    // Veriyi tekrar yükle
                    string sorgu = "SELECT * FROM views1"; // "views1" tablosunun adını değiştirmeniz gerekebilir
                    NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu, baglanti);
                    DataSet ds = new DataSet();
                    da.Fill(ds);
                    dataGridView1.DataSource = ds.Tables[0];

                    MessageBox.Show("Veri başarıyla silindi.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Silme Hatası: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Lütfen silmek istediğiniz satırı seçin.");
            }
        }

        private void p1_TextChanged(object sender, EventArgs e)
        {
            try
            {
                // p4.Text'i kullanarak kullanıcının girdiği metni alın
                string aramaMetni = p1.Text;

                // Veritabanından veri çekme sorgusu (LOWER ile küçük harfe çevriliyor)
                string sorgu = "SELECT * FROM views1 WHERE LOWER(airlines_name) LIKE LOWER('%" + aramaMetni + "%')";

                // NpgsqlDataAdapter ve DataSet oluşturma
                NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu, baglanti);
                DataSet ds = new DataSet();

                // Verileri DataSet'e doldurma
                da.Fill(ds);

                // DataGridView'e DataSet'ten gelen verileri aktarma
                dataGridView1.DataSource = ds.Tables[0];
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            airlines air1 = new airlines();
            air1.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            flights flights2 = new flights();
            flights2.ShowDialog();
        }

        //private void button7_Click(object sender, EventArgs e)
        //{
        //    baglanti.Open();
        //    NpgsqlCommand komut1 = new NpgsqlCommand("INSERT INTO flights (flight_id,airline_id, departure_airport_id, arrival_airport_id, departure_time, arrival_time, price) VALUES (@p1, @p2,@p3, " +
        //        "@p4, @p5,@p6,@p7)", baglanti);
        //    komut1.Parameters.AddWithValue("@p1",int.Parse(p2.Text));
        //    komut1.Parameters.AddWithValue("@p2", int.Parse(p3.Text));
        //    komut1.Parameters.AddWithValue("@p3", int.Parse(p4.Text));
        //    komut1.Parameters.AddWithValue("@p4", int.Parse(p5.Text));
        //    komut1.Parameters.AddWithValue("@p5", int.Parse(p6.Text));
        //    komut1.Parameters.AddWithValue("@p6", int.Parse(p7.Text));
        //    komut1.Parameters.AddWithValue("@p7", int.Parse(p7.Text));
        //    komut1.ExecuteNonQuery();
        //    baglanti.Close();
        //    MessageBox.Show("Flight information has been successfully added ");

        //}
    }
}
