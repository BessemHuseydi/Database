﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace arayuz1
{
    public partial class flights : Form
    {
        public flights()
        {
            InitializeComponent();
        }

        NpgsqlConnection baglanti = new NpgsqlConnection("Server=localHost;Port=5433;Database=VERI_TABANI_PROJE;User ID=postgres;Password=1234;");
         public void yenile()
        {
            try
            {
                string sorgu = "select * from flights";
                NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu, baglanti);
                DataSet ds = new DataSet();
                da.Fill(ds);
                dataGridView1.DataSource = ds.Tables[0];
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
        }
        
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string sorgu = "select * from flights";
                NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu, baglanti);
                DataSet ds = new DataSet();
                da.Fill(ds);
                dataGridView1.DataSource = ds.Tables[0];
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            p1.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            p2.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            p3.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            p4.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            p5.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
            p6.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
            p7.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();
            p8.Text = dataGridView1.CurrentRow.Cells[7].Value.ToString();

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                // p444.Text'i kullanarak kullanıcının girdiği metni alın
                int aramaMetni = int.Parse(p444.Text);

                // Veritabanından veri çekme sorgusu
                string sorgu = "SELECT * FROM flights WHERE flight_id = @AramaMetni";

                // NpgsqlDataAdapter ve DataSet oluşturma
                NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu, baglanti);

                // Parametreyi ekleyin
                da.SelectCommand.Parameters.AddWithValue("@AramaMetni", aramaMetni);

                DataSet ds = new DataSet();

                // Verileri DataSet'e doldurma
                da.Fill(ds);

                // DataGridView'e DataSet'ten gelen verileri aktarma
                dataGridView1.DataSource = ds.Tables[0];
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }

        }

        private void button7_Click(object sender, EventArgs e)
        {
            try
            {
                // Veritabanına yeni veri eklemek için sorgu
                string sorgu = "INSERT INTO flights (flight_id, airline_id, departure_airport_id, arrival_airport_id, departure_time, arrival_time, price,class_type) " +
                                "VALUES (@FlightID, @AirlineID, @DepartureAirportID, @ArrivalAirportID, @DepartureTime, @ArrivalTime, @Price,@class_type)";

                // NpgsqlCommand oluşturma
                using (NpgsqlCommand cmd = new NpgsqlCommand(sorgu, baglanti))
                {
                    // Parametreleri ekleyin
                    cmd.Parameters.AddWithValue("@FlightID", int.Parse(p1.Text));
                    cmd.Parameters.AddWithValue("@AirlineID", int.Parse(p2.Text));
                    cmd.Parameters.AddWithValue("@DepartureAirportID", int.Parse(p3.Text));
                    cmd.Parameters.AddWithValue("@ArrivalAirportID", int.Parse(p4.Text));
                    cmd.Parameters.AddWithValue("@DepartureTime", DateTime.Parse(p5.Text));
                    cmd.Parameters.AddWithValue("@ArrivalTime", DateTime.Parse(p6.Text));
                    cmd.Parameters.AddWithValue("@Price", decimal.Parse(p7.Text));
                    cmd.Parameters.AddWithValue("@class_type",(p8.Text));

                    // Bağlantıyı açın
                    baglanti.Open();

                    // Sorguyu çalıştırın
                    cmd.ExecuteNonQuery();
                }            

                MessageBox.Show("Veri başarıyla eklendi.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
            finally
            {
                // Bağlantıyı kapatın
                baglanti.Close();
            }

        }

        private void button6_Click(object sender, EventArgs e)
        {
            try
            {
                // p1.Text'i kullanarak kullanıcının girdiği flight_id'yi al
                int flightID = int.Parse(p1.Text);

                // Veritabanında veri güncelleme sorgusu
                string sorgu = "UPDATE flights SET airline_id = @AirlineID, " +
                               "departure_airport_id = @DepartureAirportID, arrival_airport_id = @ArrivalAirportID, " +
                               "departure_time = @DepartureTime, arrival_time = @ArrivalTime, price = @Price " +
                               "WHERE flight_id = @FlightID";

                // NpgsqlCommand oluşturma
                using (NpgsqlCommand cmd = new NpgsqlCommand(sorgu, baglanti))
                {
                    // Parametreleri ekleyin
                    cmd.Parameters.AddWithValue("@FlightID", flightID);
                    cmd.Parameters.AddWithValue("@AirlineID", int.Parse(p2.Text));
                    cmd.Parameters.AddWithValue("@DepartureAirportID", int.Parse(p3.Text));
                    cmd.Parameters.AddWithValue("@ArrivalAirportID", int.Parse(p4.Text));
                    cmd.Parameters.AddWithValue("@DepartureTime", DateTime.Parse(p5.Text));
                    cmd.Parameters.AddWithValue("@ArrivalTime", DateTime.Parse(p6.Text));
                    cmd.Parameters.AddWithValue("@Price", decimal.Parse(p7.Text));
                    cmd.Parameters.AddWithValue("@class_type", (p8.Text));
                    // Bağlantıyı açın
                    baglanti.Open();

                    // Sorguyu çalıştırın
                    int affectedRows = cmd.ExecuteNonQuery();

                    if (affectedRows > 0)
                    {
                        MessageBox.Show("Veri başarıyla güncellendi.");
                    }
                    else
                    {
                        MessageBox.Show("Belirtilen flight_id bulunamadı.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
            finally
            {
                // Bağlantıyı kapatın
                baglanti.Close();
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            try
            {
                // p1.Text'i kullanarak kullanıcının girdiği flight_id'yi al
                int flightID = int.Parse(p1.Text);

                // Veritabanından veri silme sorgusu
                string sorgu = "DELETE FROM flights WHERE flight_id = @FlightID";

                // NpgsqlCommand oluşturma
                using (NpgsqlCommand cmd = new NpgsqlCommand(sorgu, baglanti))
                {
                    // Parametre ekleyin
                    cmd.Parameters.AddWithValue("@FlightID", flightID);

                    // Bağlantıyı açın
                    baglanti.Open();

                    // Sorguyu çalıştırın
                    int affectedRows = cmd.ExecuteNonQuery();

                    if (affectedRows > 0)
                    {
                        MessageBox.Show("Veri başarıyla silindi.");
                    }
                    else
                    {
                        MessageBox.Show("Belirtilen flight_id bulunamadı.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
            finally
            {
                // Bağlantıyı kapatın
                baglanti.Close();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            airlines air1 = new airlines();
            air1.ShowDialog();

        }
    }
}
